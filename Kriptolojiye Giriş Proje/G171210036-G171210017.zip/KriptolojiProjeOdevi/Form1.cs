﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KriptolojiProjeOdevi
{
    public partial class Form1 : Form
    {
        List<int> SecilebilecekDegerler = new List<int>();
        int n;
        int phi;
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Anahtar_Click(object sender, EventArgs e)
        {

        }
        //e değerinin kontrolü için yapıldı fakat kullanmadım !!!!
        private bool EValueControl(int e)
        {
            bool returnValue = false;
            foreach (var item in SecilebilecekDegerler)
            {
                if (item == e)
                {
                    returnValue = true;
                }
            }
            return returnValue;
        }

        private void txt_DegerGetir_Click(object sender, EventArgs e)
        {
            richtxt_Olabilecekler.Clear();
            int p, q;
            try
            {
                p = Convert.ToInt32(txt_P.Text);
                q = Convert.ToInt32(txt_Q.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Lütfen Sayı Giriniz");
                throw;
            }
            n = p * q;

            phi = (p - 1) * (q - 1);

            txt_deneme.Text = n.ToString();
            txt_deneme2.Text = phi.ToString();

            for (int i = 2; i < phi; i++)
            {
                if (OBEB(phi, i) == 1)
                {
                    richtxt_Olabilecekler.Text += i.ToString() + "\n";
                    SecilebilecekDegerler.Add(i);
                }
            }

        }

        private void btn_sifrele_Click(object sender, EventArgs e)
        {
            string text;
            int E = 0;
            try
            {
                E = Convert.ToInt32(txt_E.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Lütfen Geçerli Bir Değer Giriniz!");
                throw;
            }

            
            bool activated = EValueControl(E); // Burada Çekiyorum e değerinin uygunluğunu görmek için.

            text = txt_text.Text;
            text = RSAEncrypt(text, n, E);
            txt_sifreli.Text = text;
            var privateKey = PrivateKey(E);
            txt_D.Text = privateKey.ToString();
        }

        private int OBEB(int x, int y)
        {
            int min = Math.Min(x, y);
            int obeb = 1;
            for (int i = 2; i < min; i++)
            {
                if (x%i == 0 && y%i == 0)
                {
                    obeb = i;
                }
            }
            return obeb;
        }

        private int UstelMod(int a, int b, int n)
        {
            int _a = a % n;
            int _b = b;

            if (b==0)
            {
                return 1;
            }

            while (_b > 1)
            {
                _a *= a;
                _a %= n;
                _b--;
            }
            return _a;
        }

        private int PrivateKey(int e)
        {
            int d;
            for (int i = 0;  ; i++)
            {
                if ((1+i*phi)%e==0)
                {
                    d = (1 + i * phi) / e;
                    break;
                }
            }
            return d;
        }

        private string RSAEncrypt(string metin, int n, int e)
        {
            char[] chars = metin.ToCharArray();
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < chars.Length; i++)
            {
                builder.Append(Convert.ToChar(UstelMod(chars[i], e, n)));
            }
            return builder.ToString();
        }
        private string RSADecrypt(string metin, int n, int d)
        {
            char[] chars = metin.ToCharArray();
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < chars.Length; i++)
            {
                builder.Append(Convert.ToChar(UstelMod(chars[i], d, n)));
            }
            return builder.ToString();
        }

        private void btn_coz_Click(object sender, EventArgs e)
        {
            string text = txt_sifregir.Text;
            int E = 0;
            E = Convert.ToInt32(txt_E.Text);
            var privateKey = PrivateKey(E);

            txt_Cozulmus.Text = RSADecrypt(text, n, privateKey);
        }
    }
}
