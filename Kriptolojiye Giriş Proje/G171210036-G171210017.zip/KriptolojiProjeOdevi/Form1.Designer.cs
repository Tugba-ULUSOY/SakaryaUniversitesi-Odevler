﻿namespace KriptolojiProjeOdevi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_Q = new System.Windows.Forms.TextBox();
            this.txt_P = new System.Windows.Forms.TextBox();
            this.txt_D = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_deneme = new System.Windows.Forms.TextBox();
            this.txt_deneme2 = new System.Windows.Forms.TextBox();
            this.richtxt_Olabilecekler = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_E = new System.Windows.Forms.TextBox();
            this.txt_DegerGetir = new System.Windows.Forms.Button();
            this.btn_sifrele = new System.Windows.Forms.Button();
            this.txt_text = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_sifreli = new System.Windows.Forms.TextBox();
            this.txt_Cozulmus = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_coz = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_sifregir = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(698, 97);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(495, 223);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 17);
            this.label2.TabIndex = 16;
            this.label2.Text = "Q";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "P";
            // 
            // txt_Q
            // 
            this.txt_Q.Location = new System.Drawing.Point(65, 82);
            this.txt_Q.Name = "txt_Q";
            this.txt_Q.Size = new System.Drawing.Size(151, 22);
            this.txt_Q.TabIndex = 14;
            // 
            // txt_P
            // 
            this.txt_P.Location = new System.Drawing.Point(65, 37);
            this.txt_P.Name = "txt_P";
            this.txt_P.Size = new System.Drawing.Size(151, 22);
            this.txt_P.TabIndex = 13;
            // 
            // txt_D
            // 
            this.txt_D.Location = new System.Drawing.Point(65, 224);
            this.txt_D.Name = "txt_D";
            this.txt_D.ReadOnly = true;
            this.txt_D.Size = new System.Drawing.Size(151, 22);
            this.txt_D.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 17);
            this.label3.TabIndex = 19;
            this.label3.Text = "E";
            // 
            // txt_deneme
            // 
            this.txt_deneme.Location = new System.Drawing.Point(45, 19);
            this.txt_deneme.Name = "txt_deneme";
            this.txt_deneme.Size = new System.Drawing.Size(141, 22);
            this.txt_deneme.TabIndex = 20;
            // 
            // txt_deneme2
            // 
            this.txt_deneme2.Location = new System.Drawing.Point(45, 47);
            this.txt_deneme2.Name = "txt_deneme2";
            this.txt_deneme2.Size = new System.Drawing.Size(141, 22);
            this.txt_deneme2.TabIndex = 21;
            // 
            // richtxt_Olabilecekler
            // 
            this.richtxt_Olabilecekler.Location = new System.Drawing.Point(285, 40);
            this.richtxt_Olabilecekler.Name = "richtxt_Olabilecekler";
            this.richtxt_Olabilecekler.Size = new System.Drawing.Size(80, 185);
            this.richtxt_Olabilecekler.TabIndex = 22;
            this.richtxt_Olabilecekler.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(254, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(150, 17);
            this.label4.TabIndex = 23;
            this.label4.Text = "E seçile bilecek sayılar";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 227);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 17);
            this.label5.TabIndex = 25;
            this.label5.Text = "D";
            // 
            // txt_E
            // 
            this.txt_E.Location = new System.Drawing.Point(64, 183);
            this.txt_E.Name = "txt_E";
            this.txt_E.Size = new System.Drawing.Size(151, 22);
            this.txt_E.TabIndex = 24;
            // 
            // txt_DegerGetir
            // 
            this.txt_DegerGetir.Location = new System.Drawing.Point(51, 124);
            this.txt_DegerGetir.Name = "txt_DegerGetir";
            this.txt_DegerGetir.Size = new System.Drawing.Size(165, 40);
            this.txt_DegerGetir.TabIndex = 26;
            this.txt_DegerGetir.Text = "Değerleri Getir";
            this.txt_DegerGetir.UseVisualStyleBackColor = true;
            this.txt_DegerGetir.Click += new System.EventHandler(this.txt_DegerGetir_Click);
            // 
            // btn_sifrele
            // 
            this.btn_sifrele.Location = new System.Drawing.Point(50, 348);
            this.btn_sifrele.Name = "btn_sifrele";
            this.btn_sifrele.Size = new System.Drawing.Size(165, 40);
            this.btn_sifrele.TabIndex = 27;
            this.btn_sifrele.Text = "Şifrele";
            this.btn_sifrele.UseVisualStyleBackColor = true;
            this.btn_sifrele.Click += new System.EventHandler(this.btn_sifrele_Click);
            // 
            // txt_text
            // 
            this.txt_text.Location = new System.Drawing.Point(104, 269);
            this.txt_text.Name = "txt_text";
            this.txt_text.Size = new System.Drawing.Size(151, 22);
            this.txt_text.TabIndex = 28;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 17);
            this.label6.TabIndex = 29;
            this.label6.Text = "Metni Giriniz";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 298);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 17);
            this.label7.TabIndex = 31;
            this.label7.Text = "Şifreli Hal";
            // 
            // txt_sifreli
            // 
            this.txt_sifreli.Location = new System.Drawing.Point(104, 298);
            this.txt_sifreli.Name = "txt_sifreli";
            this.txt_sifreli.ReadOnly = true;
            this.txt_sifreli.Size = new System.Drawing.Size(151, 22);
            this.txt_sifreli.TabIndex = 30;
            // 
            // txt_Cozulmus
            // 
            this.txt_Cozulmus.Location = new System.Drawing.Point(146, 71);
            this.txt_Cozulmus.Name = "txt_Cozulmus";
            this.txt_Cozulmus.ReadOnly = true;
            this.txt_Cozulmus.Size = new System.Drawing.Size(166, 22);
            this.txt_Cozulmus.TabIndex = 32;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 17);
            this.label8.TabIndex = 33;
            this.label8.Text = "Çözülmüş Hal";
            // 
            // btn_coz
            // 
            this.btn_coz.Location = new System.Drawing.Point(3, 121);
            this.btn_coz.Name = "btn_coz";
            this.btn_coz.Size = new System.Drawing.Size(165, 40);
            this.btn_coz.TabIndex = 34;
            this.btn_coz.Text = "Çöz";
            this.btn_coz.UseVisualStyleBackColor = true;
            this.btn_coz.Click += new System.EventHandler(this.btn_coz_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(34, 45);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 17);
            this.label9.TabIndex = 35;
            this.label9.Text = "Şifreli Metin";
            // 
            // txt_sifregir
            // 
            this.txt_sifregir.Location = new System.Drawing.Point(146, 39);
            this.txt_sifregir.Name = "txt_sifregir";
            this.txt_sifregir.Size = new System.Drawing.Size(166, 22);
            this.txt_sifregir.TabIndex = 36;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(28, 17);
            this.label10.TabIndex = 38;
            this.label10.Text = "Phi";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(20, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(18, 17);
            this.label11.TabIndex = 37;
            this.label11.Text = "N";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(428, 97);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(206, 17);
            this.label12.TabIndex = 39;
            this.label12.Text = "E -> Public Key Görevi Görüyor";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(428, 136);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(213, 17);
            this.label13.TabIndex = 40;
            this.label13.Text = "D -> Private Key Görevi Görüyor";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(961, 348);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(201, 17);
            this.label14.TabIndex = 41;
            this.label14.Text = "Berkay ERCİYES G171210036";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(961, 385);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(197, 17);
            this.label15.TabIndex = 42;
            this.label15.Text = "Tuğba ULUSOY G171210017";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txt_deneme);
            this.panel1.Controls.Add(this.txt_deneme2);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Location = new System.Drawing.Point(655, 339);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 90);
            this.panel1.TabIndex = 43;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btn_coz);
            this.panel2.Controls.Add(this.txt_Cozulmus);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.txt_sifregir);
            this.panel2.Location = new System.Drawing.Point(285, 246);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(321, 183);
            this.panel2.TabIndex = 44;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1237, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txt_sifreli);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_text);
            this.Controls.Add(this.btn_sifrele);
            this.Controls.Add(this.txt_DegerGetir);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_E);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.richtxt_Olabilecekler);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_D);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_Q);
            this.Controls.Add(this.txt_P);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "RSA";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_Q;
        private System.Windows.Forms.TextBox txt_P;
        private System.Windows.Forms.TextBox txt_D;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_deneme;
        private System.Windows.Forms.TextBox txt_deneme2;
        private System.Windows.Forms.RichTextBox richtxt_Olabilecekler;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_E;
        private System.Windows.Forms.Button txt_DegerGetir;
        private System.Windows.Forms.Button btn_sifrele;
        private System.Windows.Forms.TextBox txt_text;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_sifreli;
        private System.Windows.Forms.TextBox txt_Cozulmus;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_coz;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_sifregir;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}

