﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        /*Variables*/
        private int mouseStartX = 0;
        private int mouseStartY = 0;
        private int mouseCurrentX = 0;
        private int mouseCurrentY = 0;
        private int recSartPointX = 0;
        private int recSartPointY = 0;
        private int recSizeY = 0;
        private int recSizeX = 0;
        private bool mouseDown = false;
        private Bitmap bm;
        private int shapeSelected = 0;
        Pen p = new Pen(Color.Aqua);
        public Form1()
        {
            InitializeComponent();
            bm = new Bitmap(panel_cizim.Width, panel_cizim.Height);
        }

        private void panel_cizim_MouseMove(object sender, MouseEventArgs e)
        {
            mouseCurrentX = e.X - mouseStartX;
            mouseCurrentY = e.Y - mouseStartY;

            //Calculate and determine where the rectangle should be drawn.
            //The x-value of our rectangle should be the minimum between the start x-value and the current x-position
            recSartPointX = Math.Min(mouseStartX, e.X);
            //The y-value of our rectangle should also be the minimum between the start y-value and current y-value
            recSartPointY = Math.Min(mouseStartY, e.Y);
            //The width (recSizeX) of our rectangle should be the maximum between the start x-position and current x-position minus
            //the minimum of start x-position and current x-position
            recSizeX = Math.Max(mouseStartX, e.X) - Math.Min(mouseStartX, e.X);
            //For the hight(recSizeY) value, it's basically the same thing as above, but now with the y-values:
            recSizeY = Math.Max(mouseStartY, e.Y) - Math.Min(mouseStartY, e.Y);
        }

        private void panel_cizim_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mouseDown = false;
                Graphics setPaint = panel_cizim.CreateGraphics();

                if (shapeSelected == 1)
                {
                    //Draws the rectangle with the boarder.
                    setPaint.DrawRectangle(p, recSartPointX, recSartPointY, recSizeX, recSizeY);
                    setPaint.FillRectangle(new SolidBrush(p.Color), recSartPointX, recSartPointY, recSizeX, recSizeY);
                }
                else if (shapeSelected == 2)
                {
                    //draws the ellipse with the boarder.
                    setPaint.DrawEllipse(p, mouseStartX, mouseStartY, mouseCurrentX, mouseCurrentY);
                    setPaint.FillEllipse(new SolidBrush(p.Color), mouseStartX, mouseStartY, mouseCurrentX, mouseCurrentY);
                }
                else if (shapeSelected == 3)
                {

                }
            }
        }

        private void panel_cizim_Paint(object sender, PaintEventArgs e)
        {
            Graphics setPaint = e.Graphics;
            int numOfCells = 200;
            int cellSize = 5;
            Pen p = new Pen(Color.Gray);

            for (int Y = 0; Y < numOfCells; ++Y)
            {
                setPaint.DrawLine(p, 0, Y * cellSize, numOfCells * cellSize, Y * cellSize);
            }
            for (int X = 0; X < numOfCells; ++X)
            {
                setPaint.DrawLine(p, X * cellSize, 0, X * cellSize, numOfCells * cellSize);
            }
            if (mouseDown == true)
            {
                /*Sets the thickness of the line or boarder of the shapes.*/

                if (shapeSelected == 1)
                { //Draws rectangle boarder.
                    setPaint.DrawRectangle(p, recSartPointX, recSartPointY, recSizeX, recSizeY);
                }
                else if (shapeSelected == 2)
                {
                    //Draws ellipse boarder.
                    setPaint.DrawEllipse(p, mouseStartX, mouseStartY, mouseCurrentX, mouseCurrentY);
                }
                else if (shapeSelected == 3)
                {

                }
            }
            //Paints to bitmap
            setPaint.DrawImage(bm, new Point(0, 0));
        }

        private void panel_cizim_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mouseDown = true;
                mouseStartX = e.X;
                mouseStartY = e.Y;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            p.Color = Color.Red;
        }

        private void mavi_Click(object sender, EventArgs e)
        {
            p.Color = Color.Blue;
        }

        private void yesil_Click(object sender, EventArgs e)
        {
            p.Color = Color.Green;
        }

        private void turuncu_Click(object sender, EventArgs e)
        {
            p.Color = Color.Orange;
        }

        private void siyah_Click(object sender, EventArgs e)
        {
            p.Color = Color.Black;
        }

        private void sari_Click(object sender, EventArgs e)
        {
            p.Color = Color.Yellow;
        }

        private void mor_Click(object sender, EventArgs e)
        {
            p.Color = Color.Purple;
        }

        private void kahverengi_Click(object sender, EventArgs e)
        {
            p.Color = Color.Brown;
        }


        private void beyaz_Click(object sender, EventArgs e)
        {
            p.Color = Color.White;
        }

        private void kare_Click(object sender, EventArgs e)
        {
            shapeSelected = 1;
        }

        private void daire_Click(object sender, EventArgs e)
        {
            shapeSelected = 2;

        }

        private void ucgen_Click(object sender, EventArgs e)
        {
            shapeSelected = 3;

        }

        private void altıgen_Click(object sender, EventArgs e)
        {

            shapeSelected = 4;
        }

        private void kaydet_Click(object sender, EventArgs e)
        {
            Bitmap bm = new Bitmap(panel_cizim.Width, panel_cizim.Height);
            Graphics setPaint = Graphics.FromImage(bm);
            Rectangle rect = panel_cizim.RectangleToScreen(panel_cizim.ClientRectangle);
            setPaint.CopyFromScreen(rect.Location, Point.Empty, panel_cizim.Size);
            panel_cizim.Dispose();

            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Png files| *.png| jpeg files| *jpg| bitmaps| *bmp";

            if (save.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    if (File.Exists(save.FileName))
                    {
                        File.Delete(save.FileName);
                    }
                    if (save.FileName.Contains(".jpg"))
                    {
                        bm.Save(save.FileName, ImageFormat.Jpeg);
                    }
                    else if (save.FileName.Contains(".png"))
                    {
                        bm.Save(save.FileName, ImageFormat.Png);
                    }
                    else if (save.FileName.Contains(".bmp"))
                    {
                        bm.Save(save.FileName, ImageFormat.Bmp);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("File save error : " + ex.Message);
                }
            }
        }
    }
}
