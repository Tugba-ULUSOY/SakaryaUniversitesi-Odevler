﻿namespace WindowsFormsApp7
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_cizim = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dosyaOku = new System.Windows.Forms.PictureBox();
            this.kaydet = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.beyaz = new System.Windows.Forms.Button();
            this.sari = new System.Windows.Forms.Button();
            this.yesil = new System.Windows.Forms.Button();
            this.kahverengi = new System.Windows.Forms.Button();
            this.siyah = new System.Windows.Forms.Button();
            this.mavi = new System.Windows.Forms.Button();
            this.mor = new System.Windows.Forms.Button();
            this.turuncu = new System.Windows.Forms.Button();
            this.kirmizi = new System.Windows.Forms.Button();
            this.radioButton11 = new System.Windows.Forms.RadioButton();
            this.radioButton12 = new System.Windows.Forms.RadioButton();
            this.radioButton13 = new System.Windows.Forms.RadioButton();
            this.radioButton14 = new System.Windows.Forms.RadioButton();
            this.radioButton15 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.silme = new System.Windows.Forms.PictureBox();
            this.secme = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.daire = new System.Windows.Forms.PictureBox();
            this.altıgen = new System.Windows.Forms.PictureBox();
            this.ucgen = new System.Windows.Forms.PictureBox();
            this.kare = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dosyaOku)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaydet)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.silme)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.secme)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.daire)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.altıgen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucgen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kare)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel_cizim);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(-2, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(744, 543);
            this.panel1.TabIndex = 0;
            // 
            // panel_cizim
            // 
            this.panel_cizim.Location = new System.Drawing.Point(14, 14);
            this.panel_cizim.Name = "panel_cizim";
            this.panel_cizim.Size = new System.Drawing.Size(544, 515);
            this.panel_cizim.TabIndex = 5;
            this.panel_cizim.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_cizim_Paint);
            this.panel_cizim.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_cizim_MouseDown);
            this.panel_cizim.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_cizim_MouseMove);
            this.panel_cizim.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel_cizim_MouseUp);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.dosyaOku);
            this.panel5.Controls.Add(this.kaydet);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(575, 407);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(143, 123);
            this.panel5.TabIndex = 4;
            // 
            // dosyaOku
            // 
            this.dosyaOku.Image = ((System.Drawing.Image)(resources.GetObject("dosyaOku.Image")));
            this.dosyaOku.Location = new System.Drawing.Point(79, 49);
            this.dosyaOku.Name = "dosyaOku";
            this.dosyaOku.Size = new System.Drawing.Size(48, 46);
            this.dosyaOku.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.dosyaOku.TabIndex = 12;
            this.dosyaOku.TabStop = false;
            // 
            // kaydet
            // 
            this.kaydet.Image = ((System.Drawing.Image)(resources.GetObject("kaydet.Image")));
            this.kaydet.Location = new System.Drawing.Point(14, 49);
            this.kaydet.Name = "kaydet";
            this.kaydet.Size = new System.Drawing.Size(59, 46);
            this.kaydet.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kaydet.TabIndex = 11;
            this.kaydet.TabStop = false;
            this.kaydet.Click += new System.EventHandler(this.kaydet_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(5, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 15);
            this.label4.TabIndex = 11;
            this.label4.Text = "Dosya İşlemleri";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightCyan;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.radioButton5);
            this.panel3.Controls.Add(this.radioButton4);
            this.panel3.Controls.Add(this.radioButton3);
            this.panel3.Controls.Add(this.radioButton2);
            this.panel3.Controls.Add(this.radioButton1);
            this.panel3.Location = new System.Drawing.Point(575, 156);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(143, 132);
            this.panel3.TabIndex = 3;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightCyan;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.panel7);
            this.panel6.Controls.Add(this.radioButton6);
            this.panel6.Controls.Add(this.radioButton7);
            this.panel6.Controls.Add(this.radioButton8);
            this.panel6.Controls.Add(this.radioButton9);
            this.panel6.Controls.Add(this.radioButton10);
            this.panel6.Location = new System.Drawing.Point(-1, -1);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(143, 130);
            this.panel6.TabIndex = 5;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.LightCyan;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.radioButton11);
            this.panel7.Controls.Add(this.radioButton12);
            this.panel7.Controls.Add(this.radioButton13);
            this.panel7.Controls.Add(this.radioButton14);
            this.panel7.Controls.Add(this.radioButton15);
            this.panel7.Location = new System.Drawing.Point(-1, -1);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(143, 130);
            this.panel7.TabIndex = 5;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label2);
            this.panel8.Controls.Add(this.beyaz);
            this.panel8.Controls.Add(this.sari);
            this.panel8.Controls.Add(this.yesil);
            this.panel8.Controls.Add(this.kahverengi);
            this.panel8.Controls.Add(this.siyah);
            this.panel8.Controls.Add(this.mavi);
            this.panel8.Controls.Add(this.mor);
            this.panel8.Controls.Add(this.turuncu);
            this.panel8.Controls.Add(this.kirmizi);
            this.panel8.Location = new System.Drawing.Point(-1, -1);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(143, 132);
            this.panel8.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(3, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "Renk Seçimi";
            // 
            // beyaz
            // 
            this.beyaz.BackColor = System.Drawing.Color.White;
            this.beyaz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.beyaz.Location = new System.Drawing.Point(96, 102);
            this.beyaz.Name = "beyaz";
            this.beyaz.Size = new System.Drawing.Size(31, 23);
            this.beyaz.TabIndex = 8;
            this.beyaz.UseVisualStyleBackColor = false;
            this.beyaz.Click += new System.EventHandler(this.beyaz_Click);
            // 
            // sari
            // 
            this.sari.BackColor = System.Drawing.Color.Yellow;
            this.sari.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sari.Location = new System.Drawing.Point(96, 73);
            this.sari.Name = "sari";
            this.sari.Size = new System.Drawing.Size(31, 23);
            this.sari.TabIndex = 7;
            this.sari.UseVisualStyleBackColor = false;
            this.sari.Click += new System.EventHandler(this.sari_Click);
            // 
            // yesil
            // 
            this.yesil.BackColor = System.Drawing.Color.Green;
            this.yesil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.yesil.Location = new System.Drawing.Point(96, 44);
            this.yesil.Name = "yesil";
            this.yesil.Size = new System.Drawing.Size(31, 23);
            this.yesil.TabIndex = 6;
            this.yesil.UseVisualStyleBackColor = false;
            this.yesil.Click += new System.EventHandler(this.yesil_Click);
            // 
            // kahverengi
            // 
            this.kahverengi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.kahverengi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.kahverengi.Location = new System.Drawing.Point(46, 102);
            this.kahverengi.Name = "kahverengi";
            this.kahverengi.Size = new System.Drawing.Size(31, 23);
            this.kahverengi.TabIndex = 5;
            this.kahverengi.UseVisualStyleBackColor = false;
            this.kahverengi.Click += new System.EventHandler(this.kahverengi_Click);
            // 
            // siyah
            // 
            this.siyah.BackColor = System.Drawing.Color.Black;
            this.siyah.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.siyah.Location = new System.Drawing.Point(46, 73);
            this.siyah.Name = "siyah";
            this.siyah.Size = new System.Drawing.Size(31, 23);
            this.siyah.TabIndex = 4;
            this.siyah.UseVisualStyleBackColor = false;
            this.siyah.Click += new System.EventHandler(this.siyah_Click);
            // 
            // mavi
            // 
            this.mavi.BackColor = System.Drawing.Color.Blue;
            this.mavi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mavi.Location = new System.Drawing.Point(46, 44);
            this.mavi.Name = "mavi";
            this.mavi.Size = new System.Drawing.Size(31, 23);
            this.mavi.TabIndex = 3;
            this.mavi.UseVisualStyleBackColor = false;
            this.mavi.Click += new System.EventHandler(this.mavi_Click);
            // 
            // mor
            // 
            this.mor.BackColor = System.Drawing.Color.Purple;
            this.mor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mor.Location = new System.Drawing.Point(8, 102);
            this.mor.Name = "mor";
            this.mor.Size = new System.Drawing.Size(31, 23);
            this.mor.TabIndex = 2;
            this.mor.UseVisualStyleBackColor = false;
            this.mor.Click += new System.EventHandler(this.mor_Click);
            // 
            // turuncu
            // 
            this.turuncu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.turuncu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.turuncu.Location = new System.Drawing.Point(8, 73);
            this.turuncu.Name = "turuncu";
            this.turuncu.Size = new System.Drawing.Size(31, 23);
            this.turuncu.TabIndex = 1;
            this.turuncu.UseVisualStyleBackColor = false;
            this.turuncu.Click += new System.EventHandler(this.turuncu_Click);
            // 
            // kirmizi
            // 
            this.kirmizi.BackColor = System.Drawing.Color.Red;
            this.kirmizi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.kirmizi.Location = new System.Drawing.Point(8, 44);
            this.kirmizi.Name = "kirmizi";
            this.kirmizi.Size = new System.Drawing.Size(31, 23);
            this.kirmizi.TabIndex = 0;
            this.kirmizi.UseVisualStyleBackColor = false;
            this.kirmizi.Click += new System.EventHandler(this.button2_Click);
            // 
            // radioButton11
            // 
            this.radioButton11.AutoSize = true;
            this.radioButton11.Location = new System.Drawing.Point(63, 17);
            this.radioButton11.Name = "radioButton11";
            this.radioButton11.Size = new System.Drawing.Size(14, 13);
            this.radioButton11.TabIndex = 4;
            this.radioButton11.TabStop = true;
            this.radioButton11.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            this.radioButton12.AutoSize = true;
            this.radioButton12.Location = new System.Drawing.Point(63, 58);
            this.radioButton12.Name = "radioButton12";
            this.radioButton12.Size = new System.Drawing.Size(14, 13);
            this.radioButton12.TabIndex = 3;
            this.radioButton12.TabStop = true;
            this.radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton13
            // 
            this.radioButton13.AutoSize = true;
            this.radioButton13.Location = new System.Drawing.Point(8, 57);
            this.radioButton13.Name = "radioButton13";
            this.radioButton13.Size = new System.Drawing.Size(14, 13);
            this.radioButton13.TabIndex = 2;
            this.radioButton13.TabStop = true;
            this.radioButton13.UseVisualStyleBackColor = true;
            // 
            // radioButton14
            // 
            this.radioButton14.AutoSize = true;
            this.radioButton14.Location = new System.Drawing.Point(8, 94);
            this.radioButton14.Name = "radioButton14";
            this.radioButton14.Size = new System.Drawing.Size(14, 13);
            this.radioButton14.TabIndex = 1;
            this.radioButton14.TabStop = true;
            this.radioButton14.UseVisualStyleBackColor = true;
            // 
            // radioButton15
            // 
            this.radioButton15.AutoSize = true;
            this.radioButton15.Location = new System.Drawing.Point(8, 17);
            this.radioButton15.Name = "radioButton15";
            this.radioButton15.Size = new System.Drawing.Size(14, 13);
            this.radioButton15.TabIndex = 0;
            this.radioButton15.TabStop = true;
            this.radioButton15.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(63, 17);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(14, 13);
            this.radioButton6.TabIndex = 4;
            this.radioButton6.TabStop = true;
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(63, 58);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(14, 13);
            this.radioButton7.TabIndex = 3;
            this.radioButton7.TabStop = true;
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(8, 57);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(14, 13);
            this.radioButton8.TabIndex = 2;
            this.radioButton8.TabStop = true;
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(8, 94);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(14, 13);
            this.radioButton9.TabIndex = 1;
            this.radioButton9.TabStop = true;
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(8, 17);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(14, 13);
            this.radioButton10.TabIndex = 0;
            this.radioButton10.TabStop = true;
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(63, 17);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(14, 13);
            this.radioButton5.TabIndex = 4;
            this.radioButton5.TabStop = true;
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(63, 58);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(14, 13);
            this.radioButton4.TabIndex = 3;
            this.radioButton4.TabStop = true;
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(8, 57);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(14, 13);
            this.radioButton3.TabIndex = 2;
            this.radioButton3.TabStop = true;
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(8, 94);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(14, 13);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(8, 17);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(14, 13);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.silme);
            this.panel4.Controls.Add(this.secme);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(575, 294);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(143, 107);
            this.panel4.TabIndex = 3;
            // 
            // silme
            // 
            this.silme.Image = ((System.Drawing.Image)(resources.GetObject("silme.Image")));
            this.silme.Location = new System.Drawing.Point(73, 44);
            this.silme.Name = "silme";
            this.silme.Size = new System.Drawing.Size(59, 46);
            this.silme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.silme.TabIndex = 11;
            this.silme.TabStop = false;
            // 
            // secme
            // 
            this.secme.Image = ((System.Drawing.Image)(resources.GetObject("secme.Image")));
            this.secme.Location = new System.Drawing.Point(8, 44);
            this.secme.Name = "secme";
            this.secme.Size = new System.Drawing.Size(59, 46);
            this.secme.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.secme.TabIndex = 5;
            this.secme.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(5, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "Şekil İşlemleri";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.daire);
            this.panel2.Controls.Add(this.altıgen);
            this.panel2.Controls.Add(this.ucgen);
            this.panel2.Controls.Add(this.kare);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(575, 14);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(143, 136);
            this.panel2.TabIndex = 2;
            // 
            // daire
            // 
            this.daire.Image = ((System.Drawing.Image)(resources.GetObject("daire.Image")));
            this.daire.Location = new System.Drawing.Point(73, 37);
            this.daire.Name = "daire";
            this.daire.Size = new System.Drawing.Size(59, 46);
            this.daire.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.daire.TabIndex = 5;
            this.daire.TabStop = false;
            this.daire.Click += new System.EventHandler(this.daire_Click);
            // 
            // altıgen
            // 
            this.altıgen.Image = ((System.Drawing.Image)(resources.GetObject("altıgen.Image")));
            this.altıgen.Location = new System.Drawing.Point(73, 85);
            this.altıgen.Name = "altıgen";
            this.altıgen.Size = new System.Drawing.Size(59, 46);
            this.altıgen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.altıgen.TabIndex = 4;
            this.altıgen.TabStop = false;
            this.altıgen.Click += new System.EventHandler(this.altıgen_Click);
            // 
            // ucgen
            // 
            this.ucgen.Image = ((System.Drawing.Image)(resources.GetObject("ucgen.Image")));
            this.ucgen.Location = new System.Drawing.Point(8, 85);
            this.ucgen.Name = "ucgen";
            this.ucgen.Size = new System.Drawing.Size(59, 46);
            this.ucgen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ucgen.TabIndex = 3;
            this.ucgen.TabStop = false;
            this.ucgen.Click += new System.EventHandler(this.ucgen_Click);
            // 
            // kare
            // 
            this.kare.Image = ((System.Drawing.Image)(resources.GetObject("kare.Image")));
            this.kare.Location = new System.Drawing.Point(8, 37);
            this.kare.Name = "kare";
            this.kare.Size = new System.Drawing.Size(59, 46);
            this.kare.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kare.TabIndex = 1;
            this.kare.TabStop = false;
            this.kare.Click += new System.EventHandler(this.kare_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(5, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Çizim Şekli";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 540);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dosyaOku)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kaydet)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.silme)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.secme)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.daire)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.altıgen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ucgen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kare)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.RadioButton radioButton11;
        private System.Windows.Forms.RadioButton radioButton12;
        private System.Windows.Forms.RadioButton radioButton13;
        private System.Windows.Forms.RadioButton radioButton14;
        private System.Windows.Forms.RadioButton radioButton15;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button beyaz;
        private System.Windows.Forms.Button sari;
        private System.Windows.Forms.Button yesil;
        private System.Windows.Forms.Button kahverengi;
        private System.Windows.Forms.Button siyah;
        private System.Windows.Forms.Button mavi;
        private System.Windows.Forms.Button mor;
        private System.Windows.Forms.Button turuncu;
        private System.Windows.Forms.Button kirmizi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel_cizim;
        private System.Windows.Forms.PictureBox dosyaOku;
        private System.Windows.Forms.PictureBox kaydet;
        private System.Windows.Forms.PictureBox silme;
        private System.Windows.Forms.PictureBox secme;
        private System.Windows.Forms.PictureBox daire;
        private System.Windows.Forms.PictureBox altıgen;
        private System.Windows.Forms.PictureBox ucgen;
        private System.Windows.Forms.PictureBox kare;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

