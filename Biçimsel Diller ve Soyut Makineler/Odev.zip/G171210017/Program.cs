﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bicimsel_Diller
{
    class Program
    {
        static int dfa = 1;
        static void baslangic(char f)
        {
            if (f == 'a')
            {
                dfa = 2;
            }
            else if (f == 'b')
            {
                dfa = 3;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum1(char f)
        {
            if (f == 'a')
            {
                dfa = 5;
            }
            else if (f == 'b')
            {
                dfa = 6;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum2(char f)
        {
            if (f == 'a')
            {
                dfa = 4;
            }
            else if (f == 'b')
            {
                dfa = 3;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum3(char f)
        {
            if (f == 'a')
            {
                dfa = 5;
            }
            else if (f == 'b')
            {
                dfa = 9;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum4(char f)
        {
            if (f == 'a')
            {
                dfa = 2;
            }
            else if (f == 'b')
            {
                dfa = 3;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum5(char f)
        {
            if (f == 'a')
            {
                dfa = 7;
            }
            else if (f == 'b')
            {
                dfa = 13;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum6(char f)
        {
            if (f == 'a')
            {
                dfa = 8;
            }
            else if (f == 'b')
            {
                dfa = 10;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum7(char f)
        {
            if (f == 'a')
            {
                dfa = 13;
            }
            else if (f == 'b')
            {
                dfa = 6;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum8(char f)
        {
            if (f == 'a')
            {
                dfa = 7;
            }
            else if (f == 'b')
            {
                dfa = 10;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum9(char f)
        {
            if (f == 'a')
            {
                dfa = 11;
            }
            else if (f == 'b')
            {
                dfa = 13;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum10(char f)
        {
            if (f == 'a')
            {
                dfa = 13;
            }
            else if (f == 'b')
            {
                dfa = 12;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum11(char f)
        {
            if (f == 'a')
            {
                dfa = 13;
            }
            else if (f == 'b')
            {
                dfa = 10;
            }
            else
            {
                dfa = -1;
            }
        }
        static void durum12(char f)
        {
            if (f == 'a')
            {
                dfa = 13;
            }
            else if (f == 'b')
            {
                dfa = 13;
            }
            else
            {
                dfa = -1;
            }
        }

        static int isAccepted(char[] str)
        {
            // store length of string 
            int i, len = str.Length;

            for (i = 0; i < len; i++)
            {
                if (dfa == 1)
                    baslangic(str[i]);

                else if (dfa == 2)
                    durum1(str[i]);

                else if (dfa == 3)
                    durum2(str[i]);

                else if (dfa == 4)
                    durum3(str[i]);

                else if (dfa == 5)
                    durum4(str[i]);

                else if (dfa == 6)
                    durum5(str[i]);

                else if (dfa == 7)
                    durum6(str[i]);

                else if (dfa == 8)
                    durum7(str[i]);

                else if (dfa == 9)
                    durum8(str[i]);

                else if (dfa == 10)
                    durum9(str[i]);

                else if (dfa == 11)
                    durum10(str[i]);

                else if (dfa == 12)
                    durum11(str[i]);

                else if (dfa == 13)
                    durum12(str[i]);

                else
                    return 0;
            }
            if (dfa == 1 | dfa == 3 | dfa == 5 | dfa == 7 | dfa == 9 | dfa == 12)
                return 1;
            else
                return 0;
        }

        static void Main(string[] args)
        {
            Console.WriteLine("String giriniz:");
            char[] str = Console.ReadLine().ToCharArray();
            if (isAccepted(str) == 1)
                Console.Write("String Kabul Edildi.");
            else
                Console.Write("String Reddedildi!");
            Console.ReadLine();
        }
    }
}
