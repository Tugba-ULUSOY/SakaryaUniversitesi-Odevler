﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
        public enum MotorDurumu { Calisiyor, Calismiyor }
        public enum KontakAnahtariDurumu { Acik, Kapali }
        public enum GazPedaliDurumu { Basildi, Basilmadi }
        public enum FrenPedaliDurumu { Basildi, Basilmadi }
        public enum DireksiyonDurumu { SagaDonuk, SolaDonuk, Duz }
        public enum TekerleklerDurumu { AciYok ,SagaDonusAcisi , SolaDonusAcisi }
        public enum HizGostergesiDurumu { HizYok ,AracinHizi }
        public enum FarlarDurumu { KisaFar, UzunFar }
        public enum FarKumandaKoluDurumu { Kapali, KisaFarlarAcik, UzunFarlarAcik }
        public enum SinyalLambalariDurumu  { SagSinyalLambasi, SolSinyalLambasi }
        public enum SinyalKumandaKoluDurumu { Kapali, SolSinyalAcik, SagSinyalAcik, DortluSinyalAcik }

        public class ElektronikBeyin
        {

            private readonly KontakAnahtari _kontakAnahtari;
            private readonly Motor _motor;
            private readonly GazPedali _gazpedali;
            private readonly FrenPedali _frenpedali;
            private readonly Direksiyon _direksiyon;
            private readonly Tekerlekler _tekerlekler;
            private readonly HizGostergesi _hizgostergesi;
            private readonly Farlar _farlar;
            private readonly FarKumandaKolu _farKumandaKolu;
            private readonly SinyalLambalari _sinyalLambalari;
            private readonly SinyalKumandaKolu _sinyalKumandaKolu;

        public ElektronikBeyin(KontakAnahtari kontakAnahtari, Motor motor, GazPedali gazpedali, FrenPedali frenpedali, Direksiyon direksiyon, Tekerlekler tekerlekler, HizGostergesi hizgostergesi, Farlar farlar, FarKumandaKolu farKumandaKolu, SinyalLambalari sinyalLambalari, SinyalKumandaKolu sinyalKumandaKolu)
            {
                _kontakAnahtari = kontakAnahtari;
                _motor = motor;
                _gazpedali = gazpedali;
                _frenpedali = frenpedali;
                _farlar = farlar;
                _direksiyon = direksiyon;
                _tekerlekler = tekerlekler;
                _hizgostergesi = hizgostergesi;
                _farKumandaKolu = farKumandaKolu;
                _sinyalLambalari = sinyalLambalari;
                _sinyalKumandaKolu = sinyalKumandaKolu;

                // Kontağın açılması olayı gerçekleştiğinde KontakAcildi metodu otomatik olarak çalışsın
            _kontakAnahtari.KontakAcildiEventHandler += KontakAcildi;
            }

            // Kontak açıldığında bu metot otomatik olarak çalışacaktır.
            private void KontakAcildi(object sender, EventArgs e)
            {
                // Motor zaten çalışıyorsa devam etme
                if (_motor.Durum == MotorDurumu.Calisiyor) return;

                // Motoru çalıştır
                _motor.Calistir();
            }

        public class KontakAnahtari
        {
            // Kontak anahtarının durumu için salt okunur (read-only) bir özellik yazılıyor
            public KontakAnahtariDurumu Durum { get; private set; }

            // Kontak açıldığında tetiklenecek olay için event handler tanımlanıyor
            public event EventHandler KontakAcildiEventHandler;

            public KontakAnahtari()
            {
                // Kontak anahtarının başlangıç durumu kapalı olarak ayarlanıyor
                Durum = KontakAnahtariDurumu.Kapali;
            }

            public void Ac()
            {
                // Kontak zaten açıksa devam etme
                if (Durum == KontakAnahtariDurumu.Acik) return;

                // Kontağı açık konuma getir
                Durum = KontakAnahtariDurumu.Acik;

                // Bu satır test amaçlı olarak yazılmıştır
                Console.WriteLine("Kontak açıldı.");

                // Kontağın açılması olayını tetikle
                if (KontakAcildiEventHandler == null) return;
                KontakAcildiEventHandler(this, new EventArgs());
            }
        }

        public abstract class Motor
        {
            public MotorDurumu Durum { get; private set; }
            public int HizlanmaMiktari { get; set; }

            protected Motor()
            {
                // Motorun başlangıç durumu çalışmıyor olarak ayarlanıyor
                Durum = MotorDurumu.Calismiyor;
            }

            public void Calistir()
            {
                // Motor zaten çalışıyorsa devam etme
                if (Durum == MotorDurumu.Calisiyor) return;

                Durum = MotorDurumu.Calisiyor;

                // Bu satır test amaçlı olarak yazılmıştır
                Console.WriteLine("Motor çalıştı.");
            }
        }
        public class BenzinliMotor : Motor
        {
            public BenzinliMotor()
            {
                HizlanmaMiktari = 10;
            }
        }
        public class DizelliMotor : Motor
        {
            public DizelliMotor()
            {
                HizlanmaMiktari = 8;
            }
        }

        public class GazPedali : KontakAnahtari
            {
                // Gaz pedalı durumu için salt okunur (read-only) bir özellik yazılıyor
                public GazPedaliDurumu Durum { get; private set; }

                // Gaz pedalına basıldığında tetiklenecek olay için event handler tanımlanıyor
                public event EventHandler GazPedalinaBasildiEventHandler;

                public GazPedali()
                {
                    // Gaz pedalının başlangıç durumu basilmadi olarak ayarlanıyor
                    Durum = GazPedaliDurumu.Basilmadi;
                }
                public void Bas()
                {
                    // Gaz pedalına basılıysa devam etme
                    if (Durum == GazPedaliDurumu.Basildi) return;

                    // Gaz pedalı basılı konuma getir
                    Durum = GazPedaliDurumu.Basildi;

                    // Bu satır test amaçlı olarak yazılmıştır
                    Console.WriteLine("Gaz pedalına basıldı.");

                    //// Gaz pedalına basılması olayını tetikle
                    //if (GazPedalinaBasildiEventHandler == null) return;
                    //GazPedalinaBasildiEventHandler(this, new EventArgs());
                }
           
            }
            public class FrenPedali : KontakAnahtari
            {
                //  Fren pedalı durumu için salt okunur (read-only) bir özellik yazılıyor
                public FrenPedaliDurumu Durum { get; private set; }
                public int YavaslamaMiktari { get; set; }
                // Fren pedalına basıldığında tetiklenecek olay için event handler tanımlanıyor
                public event EventHandler FrenPedalinaBasildiEventHandler;

                public FrenPedali()
                {
                    // Fren pedalının başlangıç durumu basilmadi olarak ayarlanıyor
                    Durum = FrenPedaliDurumu.Basilmadi;
                }
                public void Bas()
                {
                    // Fren pedalına basılıysa devam etme
                    if (Durum == FrenPedaliDurumu.Basildi) return;

                    // Fren pedalı basılı konuma getir
                    Durum = FrenPedaliDurumu.Basildi;

                    // Bu satır test amaçlı olarak yazılmıştır
                    Console.WriteLine("Fren pedalına basıldı.");

                    // Fren pedalına basılması olayını tetikle
                    if (FrenPedalinaBasildiEventHandler == null) return;
                    FrenPedalinaBasildiEventHandler(this, new EventArgs());
                }
                public void Yavasla()
                {
                    YavaslamaMiktari = 10;
                }
            }
            public class Direksiyon : KontakAnahtari
            {
                //  Direksiyon durumu için salt okunur (read-only) bir özellik yazılıyor
                public DireksiyonDurumu Durum { get; private set; }
                public int TekerAcisi { get; set; }
                // Direksiyon döndürüldüğünde tetiklenecek olay için event handler tanımlanıyor
                public event EventHandler DireksiyonSagaDonukEventHandler;
                public event EventHandler DireksiyonSolaDonukEventHandler;
                public Direksiyon()
                {
                    // Fren pedalının başlangıç durumu basilmadi olarak ayarlanıyor
                    Durum = DireksiyonDurumu.Duz;
                }
                public void SagaDönük()
                {
                    // Direksiyon sağa dönükse devam etme
                    if (Durum == DireksiyonDurumu.SagaDonuk) return;

                    // Direksiyonu sağa dönük konuma getir
                    Durum = DireksiyonDurumu.SagaDonuk;

                    // Bu satır test amaçlı olarak yazılmıştır
                    Console.WriteLine("Direksiyon sağa döndürüldü.");

                    // Direksiyonun sağa döndürülmesi olayını tetikle
                    if (DireksiyonSagaDonukEventHandler == null) return;
                    DireksiyonSagaDonukEventHandler(this, new EventArgs());
                }

                public void SolaDönük()
                {
                    // Direksiyon sola dönükse devam etme
                    if (Durum == DireksiyonDurumu.SolaDonuk) return;

                    // Direksiyonu sola dönük konuma getir
                    Durum = DireksiyonDurumu.SolaDonuk;

                    // Bu satır test amaçlı olarak yazılmıştır
                    Console.WriteLine("Direksiyon sola döndürüldü.");

                    // Direksiyonun sola döndürülmesi olayını tetikle
                    if (DireksiyonSolaDonukEventHandler == null) return;
                    DireksiyonSolaDonukEventHandler(this, new EventArgs());
                }
                public void Aci()
                {
                    TekerAcisi = 5;
                }
            }
        public class HizGostergesi : KontakAnahtari
        {
            public HizGostergesiDurumu Durum { get; private set; }
            public int AracinHizi { get; set; }
            public event EventHandler AracinHiziEventHandler;
            public HizGostergesi()
            {
                Durum = HizGostergesiDurumu.HizYok;
            }

            public void Hiz()
            {
                if (Durum == HizGostergesiDurumu.AracinHizi) return;
                Durum = HizGostergesiDurumu.AracinHizi;
                Console.WriteLine("Aracın hızı");
                if (AracinHiziEventHandler == null) return;
                AracinHiziEventHandler(this, new EventArgs());
            }
        }

        public class Tekerlekler : KontakAnahtari
        {
            public TekerleklerDurumu Durum { get; private set; }
            public int DonusAcisi { get; set; }
            public event EventHandler TekerleklerDonduEventHandler;
            public Tekerlekler()
            {
                Durum = TekerleklerDurumu.AciYok;
            }

            public void SagaDonus()
            {
                if (DonusAcisi >= 45) return;
                Durum = TekerleklerDurumu.SagaDonusAcisi;
                Console.WriteLine("Tekerlekler sağa döndü.");
                if (TekerleklerDonduEventHandler == null) return;
                TekerleklerDonduEventHandler(this, new EventArgs());
            }

            public void SolaDonus()
            {
                if (DonusAcisi >= -45) return;
                Durum = TekerleklerDurumu.SolaDonusAcisi;
                Console.WriteLine("Tekerlekler sola döndü.");
                if (TekerleklerDonduEventHandler == null) return;
                TekerleklerDonduEventHandler(this, new EventArgs());
            }
        }

    }
    public abstract class Farlar
    {
        public FarlarDurumu Durum { get; private set; }
        // Farlar açıldığında tetiklenecek olay için event handler tanımlanıyor
        public event EventHandler FarlarAcildiEventHandler;
    }
    public class KisaFar : Farlar
    {
        public KisaFar()
        {
            
        }
    }
    
    public class UzunFar : Farlar
    {
        public UzunFar()
        {
            
        }
    }

    public abstract class SinyalLambalari
    {
        public SinyalLambalariDurumu Durum { get; private set; }
    }
    public class SagSinyalLambasi : SinyalLambalari
    {
        public SagSinyalLambasi()
        {

        }
    }
    public class SolSinyalLambasi : SinyalLambalari
    {
        public SolSinyalLambasi()
        {

        }
    }

    public class SinyalKumandaKolu 
    {
        public SinyalKumandaKoluDurumu Durum { get; private set; }
        public event EventHandler SinyalAcildiEventHandler;
        public SinyalKumandaKolu()
        {
            // SinyalKumandaKolu başlangıç durumu kapalı olarak ayarlanıyor
            Durum = SinyalKumandaKoluDurumu.Kapali;
        }

        public void SolSinyalAc()
        {
            if (Durum == SinyalKumandaKoluDurumu.SolSinyalAcik) return;
            Durum = SinyalKumandaKoluDurumu.SolSinyalAcik;
            Console.WriteLine("Sol sinyal lambaları açıldı.");
            if (SinyalAcildiEventHandler == null) return;
            SinyalAcildiEventHandler(this, new EventArgs());
        }

        public void SagSinyalAc()
        {
            if (Durum == SinyalKumandaKoluDurumu.SagSinyalAcik) return;
            Durum = SinyalKumandaKoluDurumu.SagSinyalAcik;
            Console.WriteLine("Sağ sinyal lambaları açıldı.");
            if (SinyalAcildiEventHandler == null) return;
            SinyalAcildiEventHandler(this, new EventArgs());
        }
    }

    public class FarKumandaKolu 
    {
        public FarKumandaKoluDurumu Durum { get; private set; }
        public event EventHandler FarlarAcildiEventHandler;
        public FarKumandaKolu()
        {
            // SinyalKumandaKolu başlangıç durumu kapalı olarak ayarlanıyor
            Durum = FarKumandaKoluDurumu.Kapali;
        }

        public void KisaFarlarAc()
        {
            if (Durum == FarKumandaKoluDurumu.KisaFarlarAcik) return;
            Durum = FarKumandaKoluDurumu.KisaFarlarAcik;
            Console.WriteLine("Kısa farlar açıldı.");
            if (FarlarAcildiEventHandler == null) return;
            FarlarAcildiEventHandler(this, new EventArgs());
        }

        public void UzunFarlarAc()
        {
            if (Durum == FarKumandaKoluDurumu.UzunFarlarAcik) return;
            Durum = FarKumandaKoluDurumu.UzunFarlarAcik;
            Console.WriteLine("Uzun farlar lambaları açıldı.");
            if (FarlarAcildiEventHandler == null) return;
            FarlarAcildiEventHandler(this, new EventArgs());
        }
    }
}
