﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Emgu.CV;
using Emgu.CV.UI;
using Emgu.Util;
using Emgu.CV.Structure;

namespace Ödev1
{
    public partial class Form1 : Form
    {
        Image<Bgr, byte> _InputImage;
        Image<Gray, byte> _GrayImage;
        Image<Bgr, byte> _imgInput;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string FileName = "image.jpg";
            _InputImage = new Image<Bgr, byte>(FileName);

            if (_InputImage == null)
            {
                MessageBox.Show("Resim Görüntülenemiyor!");
                return;
            }
            ımageBox1.Image = _InputImage;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (_InputImage == null)
            {
                MessageBox.Show("Resmi Seçin!");
                return;
            }
            histogramBox1.ClearHistogram();

            histogramBox1.GenerateHistograms(_InputImage, 256);

            histogramBox1.Refresh();
        }

        private void açToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                _imgInput = new Image<Bgr, byte>(ofd.FileName);
                ımageBox1.Image = _imgInput;
            }
        }

        private void çıkışToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cannyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (_imgInput == null)
            {
                return;
            }


            Image<Gray, byte> _imgCanny = new Image<Gray, byte>(_imgInput.Width, _imgInput.Height, new Gray(0));
            _imgCanny = _imgInput.Canny(50, 20);
            ımageBox1.Image = _imgCanny;
        }
    }
}
