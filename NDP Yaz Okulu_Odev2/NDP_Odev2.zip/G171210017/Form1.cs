﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;

namespace G171210017__2.Ödev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //public void AppendText(RichTextBox box, string text, Color color)
        //{
        //    box.SelectionStart = box.TextLength;
        //    box.SelectionLength = 0;

        //    box.SelectionColor = color;
        //    box.AppendText(text);
        //    box.SelectionColor = box.ForeColor;
        //}

        private void button3_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(textBox1.Text);

            double y = Convert.ToDouble(textBox2.Text);
            double sonucc;
            ArrayList sonuclar = new ArrayList();

            for (int i = 0; i < satirsayac; i++)
            {
                double dizi1 = Convert.ToDouble(ilk[i]);
                double dizi2 = Convert.ToDouble(orta[i]);
                sonucc = Math.Sqrt(Math.Pow(dizi1 - x, 2) + Math.Pow(dizi2 - y, 2));
                sonuclar.Add(sonucc);
            }
            sonuclar.Sort();
            richTextBox1.Text = richTextBox1.Text + "Küçükten büyüğe sıralama";
            foreach (double sayi1 in sonuclar)
            {
                richTextBox1.Text = richTextBox1.Text + "\n" + sayi1;

            }
        }
        int[] orta = new int[20];
        int[] ilk = new int[20];
        int[] son = new int[20];
        int sayi;
        int satirsayac = 0;
         

        private void Form1_Load(object sender, EventArgs e)
        {
            StreamReader SR_nesnesi = File.OpenText("veriler.txt");
            string satir;
            satir = SR_nesnesi.ReadLine(); //ilk satırı okur.
            while (satir != null)
            {
                string kelime = satir;
               
                string ayrilmis = satir.Substring(2, 3); //2.karakterden sonra 3.karaktere kadar
                sayi = Convert.ToInt16(ayrilmis);

                ilk[satirsayac] = sayi;

                richTextBox1.Text = richTextBox1.Text + " " + ayrilmis;

                ayrilmis = satir.Substring(8, 4);
                richTextBox1.Text = richTextBox1.Text + " " + (ayrilmis);
                
                sayi = int.Parse(ayrilmis);
                orta[satirsayac] = sayi;

                ayrilmis = satir.Substring(15, 1);
                richTextBox1.Text = richTextBox1.Text + " " + ayrilmis;

                richTextBox1.Text = richTextBox1.Text + "\n ";
                sayi = Convert.ToInt16(ayrilmis);

                son[satirsayac] = sayi;

                satir = SR_nesnesi.ReadLine(); //sonraki satırı okumak için

                satirsayac++;
            }
            SR_nesnesi.Close();

            int i = 0;
            for (int j = 0; j < richTextBox1.Lines.Length; j++)
            {
                i = j * 13;
                richTextBox1.Select(0 + i, 2 + i);
                richTextBox1.SelectionColor = Color.Green;
                richTextBox1.Select(4 + i, 7 + i);
                richTextBox1.SelectionColor = Color.Blue;
                richTextBox1.Select(9 + i, 9 + i);
                richTextBox1.SelectionColor = Color.Red;
            }


        }

        

}

}
    

