﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.Runtime;

namespace ProjeOdevi
{
    public partial class Form1 : Form
    {
        //Sınıflardan nesnleri oluşturduk..
        Graphics paper;
        Raket rkt = new Raket();
        Top top = new Top();

        //Skor için tuttuğumuz değişkenler
        public int saniye = 0;
        public int dakika = 0;

        public void oyunBaslat()        //Oyun başladığın olacak işlemler için yazdığımız fonksiyon
        {
            saniye = 0;
            dakika = 0;
            oyunbitisLbl.Visible = false;
            yenidenBaslatBtn.Visible = false;
            oyunKapatBtn.Visible = false;
            yuksekSkorBtn.Visible = false;
            Cursor.Hide();              //İmleci gizledik!
        }

        public void oyunBitis()         //Oyun bittiğinde olacak işlemler için yazdığımız fonksiyon
        {
            oyunbitisLbl.Visible = true;
            yenidenBaslatBtn.Visible = true;
            oyunKapatBtn.Visible = true;
            yuksekSkorBtn.Visible = true;
            Cursor.Show();      //imleci göster..
        }

        public Form1()
        {
            InitializeComponent();
            oyunBaslat();
            

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();             //Timerları başlattık
            timer2.Start();
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            //Topun ve raketin çizilmesi sağlandı.
            paper = e.Graphics;
            rkt.CizRaket(paper);
            top.CizTop(paper);
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            rkt.RaketHareket(e.X, this.ClientSize.Height);        // Mouse ile raketin hareketini sağladık.
            this.Invalidate();
        }
        private void timer1_Tick(object sender, EventArgs e)        //Timer1  oyunun  oynanması için gerekn fonksiyonları çalıştırıyor

        {
            
            top.HareketTop();//Topun sürekli kayması
            this.Invalidate();  //Topun düzgünce gitmesi sağlanır.
            top.IstenilenHareket(); //Sağ, sol, üst taraf ve yanma işlemleri
            top.RaketCarpma(rkt.raketDikdortgen); //Topun rakete çarpıp dönmesi
            timer1.InitializeLifetimeService();         //Timer1'in yaşam süresini yani oyun süresini denetler
        }


        private void timer2_Tick(object sender, EventArgs e)        //Timer2 süre ile ilgili işlemleri ve oyunun bitmesi durumunda olacak işlemleri tutuyor.
        {

            saniye++;
            saniye_lbl.Text = saniye.ToString();
            if (0 == saniye % 60)
            {
                saniye = 0;
                dakika++;
                dakika_lbl.Text = dakika.ToString();
            }

            if (top.topDikdortgen.Bottom >= Form1.ActiveForm.Bottom)    //Oyunun bittiği kısımı
            {
                timer1.Stop();
                timer2.Stop();
                oyunBitis();
                top.GameOver();
                
            }
   
        }
        private void oyunKapatBtn_MouseClick(object sender, MouseEventArgs e)       //Oyunu kapatma işlemi
        {
            this.Close();
        }

        private void yenidenBaslatBtn_Click(object sender, EventArgs e)             //Oyunu yeniden açma işlemi
        {
            Application.Restart();
        }

        private void yuksekSkorBtn_Click(object sender, EventArgs e)
        {
            XmlTextWriter yaz = new XmlTextWriter("YuksekSkorlar.xml", System.Text.UTF8Encoding.UTF8);
            //Daha önce bu işlemle oluşturulan bir XML dosyası varsa eski dosya silinir.
           
            YuksekSkor ys = new YuksekSkor();
            ys.Show();
        }
    }
}