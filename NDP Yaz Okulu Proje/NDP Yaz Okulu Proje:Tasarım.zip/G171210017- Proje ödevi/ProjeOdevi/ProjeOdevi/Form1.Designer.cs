﻿namespace ProjeOdevi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.skorLbl = new System.Windows.Forms.Label();
            this.saniye_lbl = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.dakika_lbl = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.oyunbitisLbl = new System.Windows.Forms.Label();
            this.oyunKapatBtn = new System.Windows.Forms.Button();
            this.yenidenBaslatBtn = new System.Windows.Forms.Button();
            this.yuksekSkorBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 60;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // skorLbl
            // 
            this.skorLbl.AutoSize = true;
            this.skorLbl.Font = new System.Drawing.Font("Arial Black", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.skorLbl.ForeColor = System.Drawing.Color.Black;
            this.skorLbl.Location = new System.Drawing.Point(10, 7);
            this.skorLbl.Name = "skorLbl";
            this.skorLbl.Size = new System.Drawing.Size(152, 52);
            this.skorLbl.TabIndex = 0;
            this.skorLbl.Text = "SKOR:";
            // 
            // saniye_lbl
            // 
            this.saniye_lbl.AutoSize = true;
            this.saniye_lbl.Font = new System.Drawing.Font("Arial Black", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.saniye_lbl.ForeColor = System.Drawing.Color.Black;
            this.saniye_lbl.Location = new System.Drawing.Point(235, 7);
            this.saniye_lbl.Name = "saniye_lbl";
            this.saniye_lbl.Size = new System.Drawing.Size(72, 52);
            this.saniye_lbl.TabIndex = 1;
            this.saniye_lbl.Text = "  0";
            // 
            // timer2
            // 
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // dakika_lbl
            // 
            this.dakika_lbl.AutoSize = true;
            this.dakika_lbl.Font = new System.Drawing.Font("Arial Black", 27.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dakika_lbl.ForeColor = System.Drawing.Color.Black;
            this.dakika_lbl.Location = new System.Drawing.Point(157, 7);
            this.dakika_lbl.Name = "dakika_lbl";
            this.dakika_lbl.Size = new System.Drawing.Size(72, 52);
            this.dakika_lbl.TabIndex = 2;
            this.dakika_lbl.Text = "0  ";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Arial Black", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label.ForeColor = System.Drawing.Color.Black;
            this.label.Location = new System.Drawing.Point(198, 9);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(31, 45);
            this.label.TabIndex = 4;
            this.label.Text = ".";
            // 
            // oyunbitisLbl
            // 
            this.oyunbitisLbl.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.oyunbitisLbl.AutoSize = true;
            this.oyunbitisLbl.BackColor = System.Drawing.Color.DimGray;
            this.oyunbitisLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.oyunbitisLbl.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.oyunbitisLbl.ForeColor = System.Drawing.Color.White;
            this.oyunbitisLbl.Location = new System.Drawing.Point(310, 188);
            this.oyunbitisLbl.Name = "oyunbitisLbl";
            this.oyunbitisLbl.Size = new System.Drawing.Size(333, 60);
            this.oyunbitisLbl.TabIndex = 5;
            this.oyunbitisLbl.Text = "\"Game Over !\"";
            this.oyunbitisLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // oyunKapatBtn
            // 
            this.oyunKapatBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.oyunKapatBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.oyunKapatBtn.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.oyunKapatBtn.ForeColor = System.Drawing.Color.Snow;
            this.oyunKapatBtn.Location = new System.Drawing.Point(768, 7);
            this.oyunKapatBtn.Name = "oyunKapatBtn";
            this.oyunKapatBtn.Size = new System.Drawing.Size(103, 39);
            this.oyunKapatBtn.TabIndex = 7;
            this.oyunKapatBtn.Text = "Oyundan Çık";
            this.oyunKapatBtn.UseVisualStyleBackColor = false;
            this.oyunKapatBtn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.oyunKapatBtn_MouseClick);
            // 
            // yenidenBaslatBtn
            // 
            this.yenidenBaslatBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.yenidenBaslatBtn.BackColor = System.Drawing.Color.Green;
            this.yenidenBaslatBtn.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.yenidenBaslatBtn.ForeColor = System.Drawing.Color.Snow;
            this.yenidenBaslatBtn.Location = new System.Drawing.Point(646, 7);
            this.yenidenBaslatBtn.Name = "yenidenBaslatBtn";
            this.yenidenBaslatBtn.Size = new System.Drawing.Size(115, 39);
            this.yenidenBaslatBtn.TabIndex = 8;
            this.yenidenBaslatBtn.Text = "Yeniden Başla";
            this.yenidenBaslatBtn.UseVisualStyleBackColor = false;
            this.yenidenBaslatBtn.Click += new System.EventHandler(this.yenidenBaslatBtn_Click);
            // 
            // yuksekSkorBtn
            // 
            this.yuksekSkorBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.yuksekSkorBtn.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.yuksekSkorBtn.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.yuksekSkorBtn.ForeColor = System.Drawing.Color.Snow;
            this.yuksekSkorBtn.Location = new System.Drawing.Point(524, 7);
            this.yuksekSkorBtn.Name = "yuksekSkorBtn";
            this.yuksekSkorBtn.Size = new System.Drawing.Size(116, 40);
            this.yuksekSkorBtn.TabIndex = 9;
            this.yuksekSkorBtn.Text = "Yüksek Skorlar";
            this.yuksekSkorBtn.UseVisualStyleBackColor = false;
            this.yuksekSkorBtn.Click += new System.EventHandler(this.yuksekSkorBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.MintCream;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(884, 554);
            this.Controls.Add(this.yuksekSkorBtn);
            this.Controls.Add(this.yenidenBaslatBtn);
            this.Controls.Add(this.oyunKapatBtn);
            this.Controls.Add(this.oyunbitisLbl);
            this.Controls.Add(this.label);
            this.Controls.Add(this.dakika_lbl);
            this.Controls.Add(this.saniye_lbl);
            this.Controls.Add(this.skorLbl);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Arcanoid";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label skorLbl;
        private System.Windows.Forms.Label saniye_lbl;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label dakika_lbl;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label oyunbitisLbl;
        private System.Windows.Forms.Button oyunKapatBtn;
        private System.Windows.Forms.Button yenidenBaslatBtn;
        private System.Windows.Forms.Button yuksekSkorBtn;
    }
}

