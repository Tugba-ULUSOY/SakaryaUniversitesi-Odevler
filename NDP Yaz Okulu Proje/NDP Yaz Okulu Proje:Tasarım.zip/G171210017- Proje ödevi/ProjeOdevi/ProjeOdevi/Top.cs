﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Media;
using System.Windows.Forms;

namespace ProjeOdevi
{
    class Top:PictureBox
    {
        //Gerekli değişkenler
        public int x, y, genislik, yukseklik;
        public int xhiz, yhiz;
        private Image topResim;
        public Rectangle topDikdortgen;
        private Random randHiz;

        public Rectangle TopRec
        {
            get { return topDikdortgen; }

        }

        public Top()        //Kurucu fonksiyon 
        {
            randHiz = new Random();
            x = 150;
            y = 20;
            genislik = 30;
            yukseklik = 30;
            xhiz = 10;
            yhiz = 10;
            topResim = ProjeOdevi.Properties.Resources.top;

            topDikdortgen = new Rectangle(x, y, genislik, yukseklik);
        }

        public void CizTop(Graphics paper)      //Top oyun alanında ilk bu fonksiyonla çizilmesi sağlanıyor
        {
            paper.DrawImage(topResim, topDikdortgen);
        }

        public void HareketTop()        //Topun başlangıç hareketi
        {
            topDikdortgen.X -= xhiz;
            topDikdortgen.Y += yhiz;

        }

        public void IstenilenHareket()
        {
            if (topDikdortgen.X >= Form1.ActiveForm.Size.Width - 50)     //Sağ tarafa çarpma durumu
            {
                xhiz *= -1;
                Boing();
            }

            if (topDikdortgen.X <= 0)            //Sol tarafa çarpma 
            {
                xhiz *= -1;
                Boing();
            }

            if (topDikdortgen.Y <= 0)          //Yukarıdan topun geri gelme durumu
            {
                yhiz *= -1;
                Boing();
            }
        }
        public void RaketCarpma(Rectangle raketDikdortgen)         //Topun rakete çarpma durumu 
        {
            if (raketDikdortgen.IntersectsWith(topDikdortgen))
            {
                yhiz *= -1;

                //Top her rakete çarptığında %10 hızlanacak bu işlemler onun için
                double sonHizX = xhiz * 10 / 100;
                double sonHizY = yhiz * 10 / 100;
                xhiz += (int)sonHizX;
                yhiz += (int)sonHizY;
                Boing();     
                        //Her rakete çarpıldığında rastgele renk değişimi sağlanıyor
                Random random = new Random();
                Form1.ActiveForm.BackColor = Color.FromArgb(random.Next(150, 255), random.Next(150, 255), random.Next(150, 255));

            }
        }

        //Ses işlemi için çarpması durumunda ve oyun bitmesi durumunda çalacak sesler

        public void Boing()
        {
            SoundPlayer oyuncu = new SoundPlayer();
            oyuncu.SoundLocation = "boing.wav";
            oyuncu.Play();
        }
        public void GameOver()
        {
            SoundPlayer oyuncu = new SoundPlayer();
            oyuncu.SoundLocation = "gameover.wav";
            oyuncu.Play();
        }

    }

}

