﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace ProjeOdevi
{
    class Raket:PictureBox
    {
        //Gerekli değişkenler
        public int x, y, genislik, yukseklik;
        private Image raketResim;
        public Rectangle raketDikdortgen;

        public Rectangle RaketDikdortgen
        {
            get { return raketDikdortgen; }

        }

        public Raket()          //Raketin kurucu fonksiyonu
        {
            x = 100;
            y = 240;
            genislik = 100;
            yukseklik = 45;

            raketResim = ProjeOdevi.Properties.Resources.cubuk; ;

            raketDikdortgen = new Rectangle(x, y, genislik, yukseklik);
        }

        public void CizRaket(Graphics paper)        //Raket bu fonksiyonla ekranda çizdiriliyor
        {
            paper.DrawImage(raketResim, raketDikdortgen);
        }

        public void RaketHareket(int mouseX, int yukseklık)     //Çubuğun ekrandan taşmama ve  ekrandaki yerini ayarlamak için yazılan fonksiyon
        {
            if (mouseX-50 <= Form1.ActiveForm.Width-112 && mouseX-50>=0 )
            {

                raketDikdortgen.X = mouseX-50;
                raketDikdortgen.Y = yukseklık - 30;
            }
        }

    }
}
